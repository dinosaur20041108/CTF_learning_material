ipt = input("Input:")
if ipt == "flag{pyth0n_i5_e@sy}":
    print("Right!")
else:
    print("Wrong!")