#include <stdio.h>
#include <windows.h>
#pragma comment(linker, "/section:.smc, RWE");

#pragma code_seg(".smc")
int SayHello()
{
	printf("Hello World!");
	return 0;
}
#pragma code_seg()

int Decode()
{
	BYTE* dwAddr = (BYTE*)SayHello;
	DWORD len = 0x38;
	DWORD dwOldProtect;

	VirtualProtect(dwAddr, 0x38, PAGE_EXECUTE_READWRITE, &dwOldProtect);

	for(int i=0; i<len;i++)
	{
		*(dwAddr+i) ^= 0xAB;
	}

	return 0;
}

int main()
{
	Decode();
	SayHello();
	return 0;
}