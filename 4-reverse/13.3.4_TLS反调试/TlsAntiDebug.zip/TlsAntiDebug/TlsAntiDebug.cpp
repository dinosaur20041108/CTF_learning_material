// TlsAntiDebug.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <windows.h>
#pragma comment(linker, "/INCLUDE:__tls_used")

void NTAPI TlsCallback_0(PVOID h, DWORD reason, PVOID pv);
extern "C" PIMAGE_TLS_CALLBACK tls_callback[] = {TlsCallback_0,0};

int main(int argc, char* argv[])
{
	printf("Hello World!\n");
	return 0;
}

void NTAPI TlsCallback_0(PVOID h, DWORD reason, PVOID pv)
{
	if(reason==DLL_PROCESS_ATTACH)
	{
		BOOL (*IsDebuggerPresent)();
		HMODULE hKernel32 = LoadLibrary("kernel32.dll");
		IsDebuggerPresent = (BOOL(*)())GetProcAddress(hKernel32, "IsDebuggerPresent");
		if(IsDebuggerPresent() == 1)
		{
			MessageBox(NULL, "EXIST DEBUG", "ERROR", MB_OK);
			ExitProcess(0);
		}
	}
};