#include <stdio.h>
#include <windows.h>

char check[][10] = {
	"OllyDbg",
	"IDA",
	"x32dbg",
	"x64dbg",
	"WinDbg"};

int myEnumWindow(HWND inHwnd)
{
	char szText[256];
	HWND hwndAfter = NULL;
	while(hwndAfter = ::FindWindowEx(inHwnd,hwndAfter,NULL,NULL))
	{
		memset(szText,0,256);
		GetWindowText(hwndAfter, szText, 256);
		
		for(int i=0;check[i][0]!=0;i++)
		{
			if(strncmp(check[i], szText, strlen(check[i])) == 0)
			{
				ExitProcess(0);
			}
		}
		myEnumWindow(hwndAfter);
	}
	return 0;
}

int main()
{
	myEnumWindow(NULL);
	printf("Hello World!\n");
	return 0;
}