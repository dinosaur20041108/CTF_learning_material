#include <stdio.h>

int MyAdd(int num1, int num2)
{
	return num1 + num2;
}

int main(int argc, char* argv[])
{
	int x=100, y=200;
	int sum = MyAdd(x, y);
	printf("%d + %d = %d\n", x, y, sum);
	return 0;
}
